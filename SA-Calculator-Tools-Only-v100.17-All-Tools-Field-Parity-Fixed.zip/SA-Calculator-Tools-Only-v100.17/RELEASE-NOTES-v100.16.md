# SA Calculator Tools Only v100.16

## Shared Loan-reference UI
- Standardized all 12 tool workspaces to the Loan field frame: 76px height, 10px radius, 15px horizontal inset, stacked label/value, 18px editable value, and blue active outline.
- Applied the shared frame to GST, Loan, Saving, Salary, Tip, SIP, Currency, Discount, Percentage, Unit, Age, and BMI.
- Kept compound controls structurally distinct where required: currency dropdowns, unit selectors/results, BMI unit switches, GST quick rates, date picker, SIP/percentage tabs, and Loan Months/Years picker.
- Kept result rows/cards separate from editable fields; no duplicate nested input borders.
- Updated the service-worker cache to v10016 so Android WebView fetches the new stylesheet.

## Release identity
- App version: `2.0.14-v100.16`
- Android version code: `1099155`
- GitHub Actions workflow: project ZIP auto-extract, nested project root detection, Android build, APK verification and artifact upload retained.

## Verification
- `npm run test:release`: 83 passed, 0 failed.
- `node --check assets/js/app.js`: passed.
- `node scripts/prepare-android-web.mjs`: 12 required Android web assets verified; source and production CSS copied byte-for-byte.
- Embedded and standalone workflow YAML are byte-identical and parse successfully.
- ZIP integrity verified.

Device-level visual/touch verification and a fresh GitHub APK build must still be confirmed after installation.
