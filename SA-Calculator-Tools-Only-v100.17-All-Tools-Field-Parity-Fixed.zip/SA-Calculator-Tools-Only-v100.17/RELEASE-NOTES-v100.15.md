# SA Calculator Tools Only v100.15 — Recording UI final correction

## Based on the 27-Nov 05:32 device recording
- Kept the v100.14 structural field repair: all standard editable fields use the same 52 CSS-pixel single-outline, stacked label/value shell as the Loan reference.
- Preserved compound layouts where the system requires them: currency amount plus currency selector, unit source/target selectors and swap, BMI measurement controls, GST quick rates and place-of-supply, Loan/Saving Months/Years, SIP Calculator/Delay tabs, Age date input, result cards and shared keypad.
- Fixed the floating “Skip to calculator workspace” pill visible over the top toolbar in Android WebView. It is now visually clipped during touch use and remains available when keyboard navigation is active.
- Retained the visible in-screen toolbar and independently scrollable tool content from v100.14.
- Bumped app, Android, service-worker and artifact versions to v100.15.
- Preserved ZIP extraction, project-root discovery and absolute APK artifact upload in GitHub Actions.

## Verification
- `npm run build:web`: passed; 12 required assets copied.
- `npm run test:release`: run before packaging; see final verification summary.
- YAML syntax and embedded/standalone workflow parity: checked before packaging.
- ZIP integrity: checked after packaging.

Physical Android device touch/visual verification and remote GitHub Actions APK build remain to be confirmed after installing the newly built APK.
