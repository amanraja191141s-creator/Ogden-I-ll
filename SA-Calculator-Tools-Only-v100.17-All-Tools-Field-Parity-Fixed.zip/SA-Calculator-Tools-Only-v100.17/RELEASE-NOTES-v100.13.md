# SA Calculator Tools Only v100.13

## Reference recording parity correction
- Re-reviewed the supplied 26-Nov-2026 screen recording frame-by-frame. The recorded tool input frames are compact 52px single-outline controls, not 76px stacked cards.
- Removed the v100.11/v100.12 global 76px field overrides that caused the installed UI to diverge from the recording.
- Restored the 52px outer control frame, 7px radius, 15px horizontal inset and blue active outline.
- Nested editable values remain transparent and borderless so a second inner box cannot appear.
- Preserved the distinct recorded controls: GST Add/Remove, 5%/18%, In-State/Out-of-State; Loan and Saving Months/Years; Salary fields; SIP tabs; Currency/Unit selectors and swap behavior; shared 4x4 keypad.
- Preserved all 12 tool workspaces and the existing calculation handlers.
- Bumped app/service-worker version to force the new Android web assets to replace cached v100.12 assets.
- Updated GitHub Actions release identity and APK artifact naming.

## Verification scope
Source-level regression tests, JavaScript syntax, generated web asset parity, YAML parsing and ZIP integrity are checked locally. Physical Android touch/pixel verification and the remote GitHub APK run remain separate checks.
