# SA Calculator Tools Only v100.17

## Recording-driven correction
- Fixed the root cause of narrow/intrinsic-width input pills: legacy child sizing and flex-basis rules could keep editable surfaces narrower than their field wrappers.
- Added a final-loaded parity stylesheet with explicit full-width, stretch-aligned input surfaces across all 12 tools.
- Kept compound selectors (Currency, Unit, BMI), GST quick-rate controls, date picker, period toggles, SIP tabs, result panels and calculator handlers intact.
- Fixed stale app-version metadata in `index.html` and `assets/js/app.js`; package, manifest, HTML, workflow and APK version code now agree.
- Added Android web asset and regression coverage for the new final stylesheet.

## Verification
Run `npm run build:web` and `npm run test:release`. Device-level visual parity and a GitHub Actions APK build still require installation/testing on a physical Android device.
