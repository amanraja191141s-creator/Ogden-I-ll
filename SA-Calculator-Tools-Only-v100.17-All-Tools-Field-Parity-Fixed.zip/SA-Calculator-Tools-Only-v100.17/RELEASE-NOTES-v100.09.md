# Release v100.09 — Global hidden-layer and tool UI cleanup

- Fixed global HTML `hidden` behavior so inactive layers remain invisible across all tools.
- Loan tenure picker now stays hidden until explicitly opened and uses a contained modal layout.
- Preserved shared numeric keypad, normal tool inputs, calculations and the 12-tool catalogue.
- Android version: `2.0.7-v100.09`; versionCode: `1099148`.
