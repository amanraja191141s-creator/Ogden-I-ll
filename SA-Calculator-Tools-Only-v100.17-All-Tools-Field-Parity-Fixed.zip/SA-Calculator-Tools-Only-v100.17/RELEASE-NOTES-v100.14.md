# SA Calculator Tools Only v100.15 — Deep UI structure repair

## What the 27-Nov recording exposed
- Tool screens were opening with the title/back toolbar clipped or crowded at the top.
- GST, Saving, Salary, SIP, Tip, Discount and Percentage inputs were rendered as compressed one-line rows: the label and editable value competed for the same horizontal line.
- The prior broad 52px wrapper rule set only dimensions and borders; it did not convert these mixed label/value wrappers into a stacked field layout. This is why the previous CSS-only parity pass did not fix the visible problem.

## Changes
- Rebuilt the shared editable field presentation as a consistent 52 CSS-pixel single-outline field with label above value, matching the Loan field scale in the reference screenshot (device density renders CSS pixels at a larger physical size).
- Made each active tool screen a column flex layout: fixed 52px toolbar plus an independently scrollable content area. This prevents toolbar clipping and keeps the title visible.
- Removed the old card/group shell styling from form wrappers so only the actual input field owns the outline.
- Kept compound controls intentionally distinct: Currency retains amount + currency selector; Unit retains source/target selectors and swap; BMI retains unit switches; GST retains Add/Remove, quick rates and place-of-supply; Loan/Saving retain Months/Years; SIP retains Calculator/Delay tabs; Age retains date input.
- Kept result rows separate from editable fields and preserved the shared keypad dock.
- Bumped service-worker cache, web version and Android version code to prevent stale assets.
- Retained the ZIP auto-extraction/project-root discovery and absolute APK artifact upload workflow fixes.

## Verification
- `npm run build:web`: passed; 12 required assets copied to `www`.
- JavaScript syntax checks: passed.
- `npm run test:release`: 78 tests passed, 0 failed.
- YAML parsing and embedded/standalone workflow parity: verified.
- ZIP integrity: verified.

Physical Android device visual/touch verification and the remote GitHub Actions APK run are not claimed as complete until the new APK is installed and checked on-device.
