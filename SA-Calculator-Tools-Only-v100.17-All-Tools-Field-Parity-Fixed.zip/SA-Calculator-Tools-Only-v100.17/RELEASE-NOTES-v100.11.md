# SA Calculator Tools Only v100.11

- Standardized all 12 tool screens to the same 76px minimum field geometry, 10px radius, 15px horizontal inset, and 16px row spacing as the Loan reference form.
- Removed nested editable-value borders/backgrounds/shadows so each field has one visible outer frame.
- Preserved compound horizontal layouts for BMI, currency, and unit conversion.
- Preserved hidden-layer protection, keypad behavior, calculations, and GitHub Actions ZIP extraction/APK artifact upload flow.
- Added all-tools Loan-field parity regression tests.
