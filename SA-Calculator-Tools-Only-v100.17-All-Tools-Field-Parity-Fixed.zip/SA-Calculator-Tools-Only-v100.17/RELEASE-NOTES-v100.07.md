# Release v100.08 — GitHub ZIP auto-extraction fix

- Fixed the actual repository layout: GitHub contains the project ZIP as a repository file, not extracted app files.
- Workflow now detects an already-extracted app or extracts exactly one `SA-Calculator-Tools-Only*.zip` before resolving the project root.
- Added explicit diagnostics for missing/multiple archives and invalid project roots.
- Preserved the Tools-only app and Android SDK/build pipeline.
- Version: `2.0.6-v100.08`; Android versionCode: `1099147`.
