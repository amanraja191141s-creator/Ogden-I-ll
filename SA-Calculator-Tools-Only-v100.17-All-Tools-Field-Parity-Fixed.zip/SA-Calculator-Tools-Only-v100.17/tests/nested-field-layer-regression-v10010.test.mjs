import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=(p)=>fs.readFileSync(new URL(`../${p}`,import.meta.url),'utf8');
test('loan fields use one outer field frame and transparent inner editable value',()=>{
 const html=read('index.html');
 for(const id of ['loan-p','loan-r','loan-tenure']) assert.match(html,new RegExp(`class="input-val-box"[^>]*id="${id}"`));
 const css=read('assets/css/tool-reference-ui.css');
 assert.match(css,/#screen-viewport #screen-loan \.loan-video-form > \.tool-field-row[\s\S]*?min-height:52px/);
 assert.match(css,/#screen-viewport #screen-loan \.loan-video-form \.input-val-box[\s\S]*?border:0 !important/);
 assert.match(css,/background:transparent !important/);
});
test('nested editable values in all tool field wrappers cannot render a second card shell',()=>{
 const css=read('assets/css/tool-reference-ui.css');
 for(const selector of ['.reference-field','.tool-field-row','.input-row','.gst-amount-field','.gst-rate-field','.bmi-reference-field']) assert.ok(css.includes(selector),`missing wrapper reset ${selector}`);
 assert.match(css,/\.field-control > \.input-val-box/);
 assert.match(css,/box-shadow:none !important/);
});
test('source and Android bundle are generated from the same root styles and markup',()=>{
 const build=read('scripts/prepare-android-web.mjs');
 assert.match(build,/await cp\(path\.join\(root, item\), path\.join\(out, item\)/);
});
