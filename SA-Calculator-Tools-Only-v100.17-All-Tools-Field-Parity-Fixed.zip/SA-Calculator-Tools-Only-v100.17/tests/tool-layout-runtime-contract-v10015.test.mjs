import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=p=>fs.readFileSync(new URL(`../${p}`,import.meta.url),'utf8');
test('v100.15 keeps accessibility skip link hidden on touch launch and available to keyboard users',()=>{
 const css=read('assets/css/tool-reference-ui.css');
 assert.match(css,/v100\.15 — Android WebView touch-focus guard/);
 assert.match(css,/\.skip-to-workspace\s*\{[\s\S]*?clip-path:\s*inset\(50%\)/);
 assert.match(css,/body\.keyboard-modality \.skip-to-workspace:focus/);
});
test('v100.15 retains the structural two-line field system and toolbar flow',()=>{
 const css=read('assets/css/tool-reference-ui.css');
 assert.match(css,/--sa-field-height:\s*52px/);
 assert.match(css,/flex-direction:\s*column\s*!important/);
 assert.match(css,/\.reference-screen-toolbar\s*\{[\s\S]*?flex:\s*0 0 52px/);
});
test('v100.16 release metadata, Android cache and both workflow copies are aligned',()=>{
 const p=JSON.parse(read('package.json')); const m=JSON.parse(read('manifest.webmanifest'));
 assert.equal(p.version,'2.0.15-v100.17'); assert.equal(p.androidVersionCode,1099156); assert.equal(m.version,p.version);
 const y=read('.github/workflows/main.yml'); const standalone=read('sa-calculator-tools-only-v100.17.yml');
 assert.equal(y,standalone); assert.match(y,/expected='2\.0\.15-v100\.17'/); assert.match(y,/versionCode='1099156'/); assert.match(y,/path:\s*\$\{\{ env\.APK_PATH \}\}/);
 assert.match(read('service-worker.js'),/sa-calculator-tools-only-v10017/);
});
