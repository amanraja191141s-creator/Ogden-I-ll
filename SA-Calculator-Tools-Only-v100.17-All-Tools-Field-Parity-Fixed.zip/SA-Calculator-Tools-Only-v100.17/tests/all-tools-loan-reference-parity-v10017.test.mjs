import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=(p)=>fs.readFileSync(new URL(`../${p}`,import.meta.url),'utf8');
test('v100.17 runtime parity stylesheet is loaded last and copied into Android web assets',()=>{
 const html=read('index.html'), prep=read('scripts/prepare-android-web.mjs'), sw=read('service-worker.js');
 assert.ok(html.indexOf('tool-parity-v10017.css')>html.indexOf('tool-reference-ui.css'));
 assert.match(prep,/assets\/css\/tool-parity-v10017\.css/);
 assert.match(sw,/assets\/css\/tool-parity-v10017\.css/);
});
test('all 12 tools receive full-width 76px Loan-reference fields, not intrinsic-width pills',()=>{
 const html=read('index.html'), css=read('assets/css/tool-parity-v10017.css');
 const ids=['salestax','loan','savings','salary','tip','sip','currencies','discount','percent','units','agecalc','bodymetrics'];
 for(const id of ids) assert.ok(html.includes(`id="screen-${id}"`),`missing ${id}`);
 for(const rule of ['min-height:76px !important','height: var(--sa-parity-field-height) !important','width:100% !important','flex: 1 1 100% !important','align-self: stretch !important','min-width:0 !important']) assert.ok(css.includes(rule),`missing runtime rule ${rule}`);
 assert.match(css,/#screen-viewport #screen-salestax \.reference-input-suffix/);
 assert.match(css,/#screen-viewport #screen-units \.input-row/);
 assert.match(css,/#screen-viewport #screen-currencies \.currency-reference-entry/);
 assert.match(css,/#screen-viewport #screen-bodymetrics \.bmi-reference-field/);
});
test('release identity is synchronized across package, manifest, HTML and workflow',()=>{
 const pkg=JSON.parse(read('package.json')), manifest=JSON.parse(read('manifest.webmanifest')), html=read('index.html'), workflow=read('.github/workflows/main.yml');
 assert.equal(pkg.version,'2.0.15-v100.17'); assert.equal(pkg.androidVersionCode,1099156); assert.equal(manifest.version,pkg.version);
 assert.ok(html.includes(`content="${pkg.version}" name="sa-build-version"`));
 assert.ok(workflow.includes(pkg.version)); assert.ok(workflow.includes(String(pkg.androidVersionCode)));
});
